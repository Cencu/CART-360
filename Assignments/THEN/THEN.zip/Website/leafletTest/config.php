<?php

//mysql database
return [
	"db" => [
		"server" => "localhost",
		"dbname" => "leaflettest",
		"user" => "root",
		"pass" => "123456"
	],
];
?>
